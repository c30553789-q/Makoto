# Makoto 0.3 — Cerebro local

Cuerpo 0.2 + motor GGUF local (llama.cpp vía JNI).

## Qué incluye
- Todo el cuerpo 0.2 (chat, historial, memoria, papelera, SAF)
- Motor `LlamaCppEngine` (CPU, arm64-v8a)
- Contexto 2048, máx. 512 tokens por respuesta, 2–4 hilos
- Prompt ChatML + memoria local
- Workflow de GitHub Actions que clona llama.cpp y compila el APK

## Modelo
Pon un GGUF (p. ej. SmolLM2-1.7B-Instruct Q4_K_M) en una carpeta de la tablet
y selecciónala en Configuración. **Nunca** dentro del APK.

## Compilar (GitHub Actions)
1. Sube este proyecto a un repo (o el ZIP + workflow que descomprime).
2. Actions → **Build Makoto APK**.
3. Descarga el artefacto `makoto-0.3-debug`.

## Hardware
Tablet Android 14, ~7 GB RAM, arm64. Solo CPU. Puede ir lento; es normal.

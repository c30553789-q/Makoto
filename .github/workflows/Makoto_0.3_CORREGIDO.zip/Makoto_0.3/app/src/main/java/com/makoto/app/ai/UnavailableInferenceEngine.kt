package com.makoto.app.ai

class UnavailableInferenceEngine : InferenceEngine {

    override val isReady: Boolean = false

    override fun loadModel(modelPath: String): Result<Unit> {
        return Result.failure(
            IllegalStateException("El motor GGUF no está disponible en este dispositivo/build.")
        )
    }

    override fun generate(prompt: String, onToken: (String) -> Unit): Result<Unit> {
        onToken("El motor de IA no está conectado. Revisa que el build incluya llama.cpp (Makoto 0.3).")
        return Result.success(Unit)
    }

    override fun unload() = Unit
}

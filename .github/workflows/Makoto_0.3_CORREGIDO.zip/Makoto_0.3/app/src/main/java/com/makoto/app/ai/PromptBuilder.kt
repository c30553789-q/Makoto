package com.makoto.app.ai

import com.makoto.app.data.ChatMessage
import com.makoto.app.data.MemoryItem

/**
 * Arma el prompt en formato ChatML (SmolLM2 / similares).
 * Mantiene el historial corto para no explotar la RAM.
 */
object PromptBuilder {

    private const val SYSTEM = """Eres Makoto, una asistente local, cercana y útil. Responde en el idioma del usuario. Sé concisa cuando baste."""

    fun build(
        userText: String,
        history: List<ChatMessage>,
        memory: List<MemoryItem>,
        maxHistoryMessages: Int = 12
    ): String {
        val sb = StringBuilder()
        sb.append("<|im_start|>system\n")
        sb.append(SYSTEM)
        if (memory.isNotEmpty()) {
            sb.append("\n\nNotas de memoria local:\n")
            memory.take(8).forEach { sb.append("- ").append(it.text).append('\n') }
        }
        sb.append("<|im_end|>\n")

        val recent = history.takeLast(maxHistoryMessages)
        for (m in recent) {
            if (m.fromUser) {
                sb.append("<|im_start|>user\n").append(m.text).append("<|im_end|>\n")
            } else {
                sb.append("<|im_start|>assistant\n").append(m.text).append("<|im_end|>\n")
            }
        }
        sb.append("<|im_start|>user\n").append(userText).append("<|im_end|>\n")
        sb.append("<|im_start|>assistant\n")
        return sb.toString()
    }
}

package com.makoto.app.model

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.DocumentsContract
import com.makoto.app.storage.LocalStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class ModelManager(context: Context) {
    private val appContext = context.applicationContext
    private val store = LocalStore(appContext)

    fun saveTree(uri: Uri): Result<Unit> = runCatching {
        val resolver = appContext.contentResolver
        val readFlag = Intent.FLAG_GRANT_READ_URI_PERMISSION
        val writeFlag = Intent.FLAG_GRANT_WRITE_URI_PERMISSION

        val persisted = runCatching {
            resolver.takePersistableUriPermission(uri, readFlag or writeFlag)
            readFlag or writeFlag
        }.getOrElse {
            resolver.takePersistableUriPermission(uri, readFlag)
            readFlag
        }

        // Verify that the provider can actually be opened before remembering it.
        resolver.query(uri, arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID), null, null, null)?.use { }
            ?: throw IllegalStateException("Android no pudo abrir la carpeta seleccionada.")

        store.saveModelTreeUri(uri.toString())
    }

    fun clearTree() {
        store.getModelTreeUri()?.let { saved ->
            val uri = Uri.parse(saved)
            val flags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            runCatching { appContext.contentResolver.releasePersistableUriPermission(uri, flags) }
            runCatching { appContext.contentResolver.releasePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
        }
        store.clearModelTreeUri()
    }

    fun getSavedTree(): Uri? = store.getModelTreeUri()?.let(Uri::parse)

    suspend fun findGgufFiles(treeUri: Uri): List<String> = withContext(Dispatchers.IO) {
        findGgufFilesRecursive(treeUri, mutableSetOf())
    }

    private fun findGgufFilesRecursive(treeUri: Uri, visited: MutableSet<String>): List<String> {
        val result = mutableListOf<String>()
        val rootId = runCatching { DocumentsContract.getTreeDocumentId(treeUri) }.getOrNull() ?: return result
        visitDocument(treeUri, rootId, visited, result)
        return result
    }

    private fun visitDocument(
        treeUri: Uri,
        documentId: String,
        visited: MutableSet<String>,
        result: MutableList<String>
    ) {
        if (!visited.add(documentId)) return

        val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, documentId)
        val projection = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE
        )

        appContext.contentResolver.query(childrenUri, projection, null, null, null)?.use { cursor ->
            val idIndex = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DOCUMENT_ID)
            val nameIndex = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_DISPLAY_NAME)
            val mimeIndex = cursor.getColumnIndexOrThrow(DocumentsContract.Document.COLUMN_MIME_TYPE)

            while (cursor.moveToNext()) {
                val id = cursor.getString(idIndex)
                val name = cursor.getString(nameIndex)
                val mime = cursor.getString(mimeIndex)
                if (name.lowercase().endsWith(".gguf")) result += id
                if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                    visitDocument(treeUri, id, visited, result)
                }
            }
        }
    }

    /**
     * Abre el primer .gguf encontrado (o el documentId indicado) y devuelve un
     * ParcelFileDescriptor de solo lectura. El llamador debe cerrarlo.
     */
    fun openModelFd(treeUri: Uri, documentId: String? = null): android.os.ParcelFileDescriptor {
        val id = documentId ?: findGgufFilesRecursive(treeUri, mutableSetOf()).firstOrNull()
            ?: throw IllegalStateException("No hay ningún archivo .gguf en la carpeta.")
        val docUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, id)
        return appContext.contentResolver.openFileDescriptor(docUri, "r")
            ?: throw IllegalStateException("No se pudo abrir el archivo del modelo.")
    }
}

package com.makoto.app.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.makoto.app.MakotoViewModel
import com.makoto.app.data.ChatMessage
import com.makoto.app.data.Conversation
import com.makoto.app.data.MemoryItem

private enum class Screen { CHAT, HISTORY, MEMORY, TRASH, SETTINGS }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MakotoApp(viewModel: MakotoViewModel = viewModel()) {
    val active by viewModel.active.collectAsState()
    val trash by viewModel.trash.collectAsState()
    val memory by viewModel.memory.collectAsState()
    val selectedId by viewModel.selectedId.collectAsState()
    val selectedTree by viewModel.selectedTree.collectAsState()
    val modelCount by viewModel.modelCount.collectAsState()
    val modelScanError by viewModel.modelScanError.collectAsState()

    var screen by remember { mutableStateOf(Screen.CHAT) }
    var input by remember { mutableStateOf("") }
    var pendingDelete by remember { mutableStateOf<Long?>(null) }

    val selected = active.firstOrNull { it.id == selectedId } ?: active.firstOrNull()

    val folderPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri: Uri? ->
        if (uri != null) {
            viewModel.saveModelTree(uri)
        }
    }

    if (pendingDelete != null) {
        AlertDialog(
            onDismissRequest = { pendingDelete = null },
            title = { Text("Eliminar conversación") },
            text = { Text("Se borrará definitivamente. Esta acción no se puede deshacer.") },
            confirmButton = {
                Button(onClick = {
                    viewModel.permanentlyDelete(pendingDelete!!)
                    pendingDelete = null
                }) { Text("Eliminar") }
            },
            dismissButton = {
                Button(onClick = { pendingDelete = null }) { Text("Cancelar") }
            }
        )
    }

    when (screen) {
        Screen.CHAT -> ChatScreen(
            selected = selected,
            input = input,
            onInput = { input = it },
            onSend = {
                viewModel.sendMessage(input)
                input = ""
            },
            onSettings = { screen = Screen.SETTINGS }
        )
        Screen.HISTORY -> HistoryScreen(
            items = active,
            selectedId = selectedId,
            onSelect = { id ->
                viewModel.selectConversation(id)
                screen = Screen.CHAT
            },
            onTrash = { screen = Screen.TRASH },
            onNew = {
                viewModel.createConversation()
                screen = Screen.CHAT
            },
            onMoveToTrash = { id -> viewModel.moveToTrash(id) }
        )
        Screen.MEMORY -> MemoryScreen(
            items = memory,
            onAdd = { viewModel.addMemory(it) },
            onDelete = { viewModel.deleteMemory(it) }
        )
        Screen.TRASH -> TrashScreen(
            items = trash,
            onRestore = { viewModel.restore(it) },
            onDelete = { pendingDelete = it },
            onBack = { screen = Screen.HISTORY }
        )
        Screen.SETTINGS -> SettingsScreen(
            selectedTree = selectedTree,
            modelCount = modelCount,
            modelScanError = modelScanError,
            onPick = { folderPicker.launch(null) },
            onClear = { viewModel.clearModelTree() },
            onBack = { screen = Screen.CHAT }
        )
    }

    if (screen == Screen.CHAT) {
        Row(
            Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(horizontal = 8.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            IconButton(onClick = { screen = Screen.HISTORY }) {
                Icon(Icons.Default.History, contentDescription = "Historial")
            }
            IconButton(onClick = { screen = Screen.MEMORY }) {
                Icon(Icons.Default.Memory, contentDescription = "Memoria")
            }
            IconButton(onClick = { screen = Screen.SETTINGS }) {
                Icon(Icons.Default.Settings, contentDescription = "Configuración")
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ChatScreen(
    selected: Conversation?,
    input: String,
    onInput: (String) -> Unit,
    onSend: () -> Unit,
    onSettings: () -> Unit
) {
    val listState = rememberLazyListState()
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Makoto", fontWeight = FontWeight.Bold) },
                actions = {
                    IconButton(onClick = onSettings) {
                        Icon(Icons.Default.Settings, contentDescription = "Configuración")
                    }
                }
            )
        },
        bottomBar = {
            Row(
                Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surface)
                    .navigationBarsPadding()
                    .padding(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = input,
                    onValueChange = onInput,
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("Escribe un mensaje...") },
                    maxLines = 4
                )
                Spacer(Modifier.width(8.dp))
                IconButton(onClick = onSend, modifier = Modifier.size(52.dp)) {
                    Icon(
                        Icons.Default.Send,
                        contentDescription = "Enviar",
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }
    ) { padding ->
        LazyColumn(
            state = listState,
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(selected?.messages ?: emptyList(), key = { it.id }) { message ->
                MessageBubble(message)
            }
            item { Spacer(Modifier.height(12.dp)) }
        }
    }
    LaunchedEffect(selected?.messages?.size) {
        val count = selected?.messages?.size ?: 0
        if (count > 0) {
            listState.animateScrollToItem(count - 1)
        }
    }
}

@Composable
private fun MessageBubble(message: ChatMessage) {
    val isUser = message.fromUser
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
    ) {
        Text(
            text = message.text,
            modifier = Modifier
                .background(
                    if (isUser) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                    RoundedCornerShape(12.dp)
                )
                .padding(horizontal = 12.dp, vertical = 8.dp),
            color = if (isUser) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun HistoryScreen(
    items: List<Conversation>,
    selectedId: Long,
    onSelect: (Long) -> Unit,
    onTrash: () -> Unit,
    onNew: () -> Unit,
    onMoveToTrash: (Long) -> Unit
) {
    Scaffold(topBar = { TopAppBar(title = { Text("Historial") }) }) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Button(onClick = onNew, Modifier.fillMaxWidth()) { Text("Nueva conversación") }
            Button(onClick = onTrash, Modifier.fillMaxWidth()) { Text("Papelera") }
            if (items.isEmpty()) {
                Text("No hay conversaciones.")
            } else {
                items.forEach { c ->
                    Row(
                        Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Button(
                            onClick = { onSelect(c.id) },
                            Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (c.id == selectedId) {
                                    MaterialTheme.colorScheme.secondary
                                } else {
                                    MaterialTheme.colorScheme.surfaceVariant
                                },
                                contentColor = MaterialTheme.colorScheme.onSurface
                            )
                        ) {
                            Text(c.title)
                        }
                        IconButton(onClick = { onMoveToTrash(c.id) }) {
                            Icon(Icons.Default.Delete, contentDescription = "Mover a papelera")
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MemoryScreen(
    items: List<MemoryItem>,
    onAdd: (String) -> Unit,
    onDelete: (Long) -> Unit
) {
    var text by remember { mutableStateOf("") }
    Scaffold(topBar = { TopAppBar(title = { Text("Memoria local") }) }) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Algo que Makoto debe recordar...") }
            )
            Button(
                onClick = {
                    onAdd(text)
                    text = ""
                },
                Modifier.fillMaxWidth()
            ) {
                Text("Guardar memoria")
            }
            HorizontalDivider()
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(items, key = { it.id }) { item ->
                    Row(
                        Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(item.text, Modifier.weight(1f))
                        IconButton(onClick = { onDelete(item.id) }) {
                            Icon(Icons.Default.Delete, contentDescription = "Eliminar")
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TrashScreen(
    items: List<Conversation>,
    onRestore: (Long) -> Unit,
    onDelete: (Long) -> Unit,
    onBack: () -> Unit
) {
    Scaffold(topBar = { TopAppBar(title = { Text("Papelera") }) }) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            Button(onClick = onBack, Modifier.fillMaxWidth()) { Text("Volver al historial") }
            Spacer(Modifier.height(12.dp))
            if (items.isEmpty()) {
                Text("La papelera está vacía.")
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(items, key = { it.id }) { c ->
                        Row(
                            Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(c.title, Modifier.weight(1f))
                            IconButton(onClick = { onRestore(c.id) }) {
                                Icon(Icons.Default.Restore, contentDescription = "Restaurar")
                            }
                            IconButton(onClick = { onDelete(c.id) }) {
                                Icon(Icons.Default.Delete, contentDescription = "Eliminar definitivamente")
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun SettingsScreen(
    selectedTree: Uri?,
    modelCount: Int,
    modelScanError: String?,
    onPick: () -> Unit,
    onClear: () -> Unit,
    onBack: () -> Unit
) {
    Scaffold(topBar = { TopAppBar(title = { Text("Configuración") }) }) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(
                "Modelo de IA",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold
            )
            Text(
                when {
                    selectedTree == null -> "No hay una carpeta de modelos configurada."
                    modelScanError != null -> modelScanError
                    else -> "Carpeta configurada. GGUF encontrados: $modelCount"
                }
            )
            Button(onClick = onPick, Modifier.fillMaxWidth()) {
                Icon(Icons.Default.FolderOpen, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("Seleccionar carpeta de modelos")
            }
            if (selectedTree != null) {
                Button(onClick = onClear, Modifier.fillMaxWidth()) {
                    Text("Quitar carpeta")
                }
            }
            HorizontalDivider()
            Text("Makoto usa el selector de carpetas de Android. El modelo permanece fuera del APK.")
            Text("Esta versión 0.2 prepara el cuerpo completo. El motor GGUF real llegará en la fase 0.3.")
            Button(onClick = onBack, Modifier.fillMaxWidth()) {
                Text("Volver al chat")
            }
        }
    }
}

package com.makoto.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.makoto.app.ui.MakotoApp
import com.makoto.app.ui.theme.MakotoTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            MakotoTheme {
                MakotoApp()
            }
        }
    }
}
